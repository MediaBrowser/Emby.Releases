﻿define(['jQuery'], function ($) {

    return function (view, params, tabContent) {

        var self = this;
        var data = {};

        function getPageData(context) {
            var key = getSavedQueryKey(context);
            var pageData = data[key];

            if (!pageData) {
                pageData = data[key] = {
                    query: {
                        StartIndex: 0,
                        EnableFavoriteSorting: true,
                        Limit: LibraryBrowser.getDefaultPageSize()
                    }
                };

                LibraryBrowser.loadSavedQueryValues(key, pageData.query);
            }
            return pageData;
        }

        function getQuery(context) {

            return getPageData(context).query;
        }

        function getSavedQueryKey(context) {

            if (!context.savedQueryKey) {
                context.savedQueryKey = LibraryBrowser.getSavedQueryKey('channels');
            }
            return context.savedQueryKey;
        }

        function getChannelsHtml(channels) {

            return LibraryBrowser.getPosterViewHtml({
                items: channels,
                shape: "square",
                showTitle: true,
                lazy: true,
                cardLayout: true,
                showDetailsMenu: true
            });
        }

        function renderChannels(context, result) {

            var query = getQuery(context);

            $('.listTopPaging', context).html(LibraryBrowser.getQueryPagingHtml({
                startIndex: query.StartIndex,
                limit: query.Limit,
                totalRecordCount: result.TotalRecordCount,
                showLimit: false,
                updatePageSizeSetting: false,
                filterButton: true
            }));

            var html = getChannelsHtml(result.Items);

            var elem = context.querySelector('#items');
            elem.innerHTML = html;
            ImageLoader.lazyChildren(elem);

            $('.btnNextPage', context).on('click', function () {
                query.StartIndex += query.Limit;
                reloadItems(context);
            });

            $('.btnPreviousPage', context).on('click', function () {
                query.StartIndex -= query.Limit;
                reloadItems(context);
            });

            $('.btnFilter', context).on('click', function () {
                showFilterMenu(context);
            });

            LibraryBrowser.saveQueryValues(getSavedQueryKey(context), query);
        }

        function showFilterMenu(context) {

            require(['components/filterdialog/filterdialog'], function (filterDialogFactory) {

                var filterDialog = new filterDialogFactory({
                    query: getQuery(context),
                    mode: 'livetvchannels'
                });

                Events.on(filterDialog, 'filterchange', function () {
                    reloadItems(context);
                });

                filterDialog.show();
            });
        }

        function reloadItems(context) {

            Dashboard.showLoadingMsg();

            var query = getQuery(context);

            query.UserId = Dashboard.getCurrentUserId();

            ApiClient.getLiveTvChannels(query).then(function (result) {

                renderChannels(context, result);

                Dashboard.hideLoadingMsg();
            });
        }

        self.renderTab = function () {

            reloadItems(tabContent);
        };
    };

});