﻿var Logger = {

    log: function (str) {
        console.log(str);
    }
};