﻿(function () {

    function getLocalMediaSource(serverId, itemId) {
        return null;
    }

    window.LocalAssetManager = {
        getLocalMediaSource: getLocalMediaSource
    };

})();