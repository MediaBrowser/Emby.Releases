define(['connectionManager', 'events'], function (connectionManager, events) {
    'use strict';

    events.on(connectionManager, 'credentialsupdated', function (e, data) {

        // sync the credentials object to the native side
        // Use whichever one you need
        //var obj = data.credentials;
        //var json = data.credentialsJson;
        window.webkit.messageHandlers.nativeCredentials.postMessage({
            event: 'credentialsupdated',
            data: data.credentialsJson
        });
    });

    events.on(connectionManager, 'serveraddresschanged', function (e, data) {

        window.webkit.messageHandlers.nativeCredentials.postMessage({
            event: 'serveraddresschanged',
            serverId: data.apiClient.serverId(),
            address: data.address
        });
    });
});