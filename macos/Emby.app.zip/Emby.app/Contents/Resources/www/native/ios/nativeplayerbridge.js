define([], function () {
    
    'use strict';

    const NativeMpvPlayer = {

        playAudio(instance, itemsJson, isLocal, mediaSourceJson, startIndex, startPosMs) {
            window.MpvAudioPlayer = instance;
            window.webkit.messageHandlers.playAudio.postMessage({
                items: itemsJson,
                isLocal: isLocal,
                mediaSourceJson: mediaSourceJson,
                startIndex: startIndex,
                startPosMs: startPosMs,
            });
        },

        sendPlayerCommand(command, arg) {
            window.webkit.messageHandlers.sendMpvCommand.postMessage({
                command: command,
                arg: arg
            });
        },

        queueItems(mediaItemsJson, next) {
            window.webkit.messageHandlers.queueItems.postMessage({
                items: mediaItemsJson,
                next: next
            });
        },

        removeFromPlaylist(index) {
            window.webkit.messageHandlers.removeFromPlaylist.postMessage({
                index: index
            });
        },

        movePlaylistItem(oldIndex, newIndex) {
            window.webkit.messageHandlers.movePlaylistItem.postMessage({
                oldIndex: oldIndex,
                newIndex: newIndex
            });
        }
    };

    if (!window.NativeMpvPlayer) {
        window.NativeMpvPlayer = NativeMpvPlayer;
    }
});