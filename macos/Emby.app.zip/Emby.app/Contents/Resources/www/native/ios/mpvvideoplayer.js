define(['events', 'connectionManager', 'globalize', 'playbackManager', 'apiclient', 'appRouter', './mediaprofilebuilder'], function (events, connectionManager, globalize, playbackManager, ApiClient, appRouter, mediaProfileBuilder) {
	'use strict';

	function sendMpvCommand(command, value) {
		EmbyPlayer.sendPlayerCommand(command, value);
	}

	class MpvVideoPlayer {
		constructor() {
			const self = this;
			self.name = 'LibMpv Video Player';

			self.type = 'mediaplayer';
			self.id = 'mpvvideoplayer';
			self.isLocalPlayer = true;

			globalThis.MpvVideoPlayer = self;

			let currentAspectRatio = 'auto';
			let currentPlayResolve;
			let currentPlayReject;
			let playerState = {};

			function onTimeUpdate() {
				events.trigger(self, 'timeupdate');
			}

			function onVolumeChange() {
				events.trigger(self, 'volumechange');
			}

			function onBrightnessChange() {
				events.trigger(self, 'brightnesschange');
			}

			function onUnpause() {
				events.trigger(self, 'unpause');
			}

			function onPause() {
				events.trigger(self, 'pause');
			}

			function onRateChange() {
				events.trigger(self, 'playbackratechange');
			}

			function onPipModeChanged(isEnabled) {
				playerState.pipEnabled = isEnabled;
			}

			function onError() {
				const reject = currentPlayReject;

				if (reject) {
					playerState.started = null;
					currentPlayReject = null;
					currentPlayResolve = null;

					reject();
					self.destroy();
					return;
				}

				if (playerState.started) {
					playerState.started = null;

					events.trigger(self, 'error', [
						{
							type: 'mediadecodeerror'
						}
					]);
				}
			}

			function onEnded() {
				const state = playerState;

				if (state.started) {
					state.started = null;
					currentPlayReject = null;
					currentPlayResolve = null;

					const stopInfo = {
						self: state.currentSrc
					};

					events.trigger(self, 'stopped', [stopInfo]);
				}
			}

			self.canSetAudioStreamIndex = () => true;

			let supportedFeatures;

			function getSupportedFeatures() {
				const list = [];

				list.push('SetBrightness');
				list.push('SetAspectRatio');
				list.push('SetPlaybackRate');
				list.push('SetSubtitleOffset');

				if (window.isPictureInPictureSupported) {
					list.push('PictureInPicture');
				}

				return list;
			}

			self.supports = feature => {
				if (!supportedFeatures) {
					supportedFeatures = getSupportedFeatures();
				}

				return supportedFeatures.includes(feature);
			};

			self.setAspectRatio = val => {
				currentAspectRatio = val;
				sendMpvCommand('setAspectRatio', val);
			};

			self.getAspectRatio = () => currentAspectRatio;

			self.getSupportedAspectRatios = () => [
				{ name: globalize.translate('Auto'), id: 'auto' },
				{ name: globalize.translate('Cover'), id: 'cover' },
				{ name: globalize.translate('Fill'), id: 'fill' }
			];

			function getTextTrackUrl(subtitleStream, item, mediaSource) {

				if ((ApiClient.isLocalItem(item) || mediaSource.IsLocal) && subtitleStream.Path) {
					return subtitleStream.Path;
				}

				return playbackManager.getSubtitleUrl(subtitleStream, item.ServerId);
			}

			self.setSubtitleStreamIndex = index => {
				sendMpvCommand('setSubtitleStreamIndex', index);
			};

			self.setAudioStreamIndex = index => {
				sendMpvCommand('setAudioStreamIndex', index);
			};

			self.canPlayMediaType = mediaType => {
				mediaType = (mediaType || '').toLowerCase();

				if (mediaType === 'audio') {
					return false;
				}

				if (mediaType === 'video') {
					return true;
				}

				return false;
			};

			self.getDeviceProfile = item => {
				return mediaProfileBuilder.buildProfile({
					item: item
				});
			};

			self.currentTime = val => {
				if (val != null) {
					return self.seek(val);
				}

				if (playerState) {
					return playerState.currentTime;
				}

				return null;
			};

			self.seek = val => {
				sendMpvCommand('setPosition', val);
			};

			self.seekRelative = val => {
				sendMpvCommand('seekRelative', val);
			};

			self.duration = () => {
				if (playerState) {
					return playerState.duration;
				}

				return null;
			};

			self.stop = destroyPlayer =>
				new Promise(resolve => {
					sendMpvCommand('stop', (destroyPlayer || false).toString());

					setTimeout(() => {
						onEnded();

						if (destroyPlayer) {
							onPlayerDestroy();
						}

						resolve();
					}, 500);
				});

			self.playPause = () => {
				sendMpvCommand('playPause', null);
			};

			self.pause = () => {
				sendMpvCommand('pause', null);
			};

			self.unpause = () => {
				sendMpvCommand('unpause', null);
			};

			let brightnessValue = 100;
			self.setBrightness = val => {
				sendMpvCommand('setBrightness', val);
			};

			self.getBrightness = () => brightnessValue;

			self.notifyBrightnessChange = val => {
				brightnessValue = val;
				onBrightnessChange();
			};

			self.setVolume = val => {
				if (val != null) {
					sendMpvCommand('setVolume', val.toString());
				}
			};

			self.getVolume = () => {
				if (playerState) {
					return playerState.volume;
				}
			};

			self.volume = val => {
				if (val != null) {
					return self.setVolume(val);
				}

				return self.getVolume();
			};

			self.volumeUp = () => {
				sendMpvCommand('volumeUp');
			};

			self.volumeDown = () => {
				sendMpvCommand('volumeDown');
			};

			self.notifyVolumeChange = (val, changedByUser, muted) => {
				playerState.volume = val;
				playerState.muted = muted;
				if (changedByUser) {
					onVolumeChange();
				}
			};

			self.setMute = mute => {
				sendMpvCommand('setMute', mute.toString());
			};

			self.isMuted = () => {
				if (playerState) {
					return playerState.muted;
				}

				return false;
			};

			function imageUrl(item, options = {}) {
				options.type = options.type || 'Primary';

				if (item.Type === 'TvChannel' && item.CurrentProgram && item.CurrentProgram.ImageTags && item.CurrentProgram.ImageTags.Primary != null) {
					options.tag = item.CurrentProgram.ImageTags.Primary;
					return connectionManager.getApiClient(item.ServerId).getScaledImageUrl(item.CurrentProgram.Id, options);
				}

				if (item.SeriesPrimaryImageTag && item.SeriesId) {
					options.tag = item.SeriesPrimaryImageTag;
					return connectionManager.getApiClient(item.ServerId).getScaledImageUrl(item.SeriesId, options);
				}

				if (item.ImageTags && item.ImageTags[options.type]) {
					options.tag = item.ImageTags[options.type];
					return connectionManager.getApiClient(item.ServerId).getScaledImageUrl(item.Id, options);
				}

				if (item.AlbumId && item.AlbumPrimaryImageTag) {
					options.tag = item.AlbumPrimaryImageTag;
					return connectionManager.getApiClient(item.ServerId).getScaledImageUrl(item.AlbumId, options);
				}

				return null;
			}

			self.play = options => {

				if (options.fullscreen !== false) {
					appRouter.showVideoOsd();
				}
				// eslint-disable-next-line no-async-promise-executor
				return new Promise(async (resolve, reject) => {
					try {
						currentPlayResolve = resolve;
						currentPlayReject = reject;

						const item = options.item;
						const mediaSource = options.mediaSource;

						let val = options.url;

						console.log("Sending " + val + " to player");

						const tIndex = val.indexOf('#t=');
						const startPosMs = (options.playerStartPositionTicks || 0) / 10000;

						if (tIndex !== -1) {
							val = val.split('#')[0];
						}

						playerState.mediaType = options.mediaType;

						const posterUrl = imageUrl(item, {
							type: 'Primary'
						});

						if (options.mediaType === 'Video') {
							const videoStreamIndex = -1;
							const audioStreamIndex =
								mediaSource.DefaultAudioStreamIndex == null ? -1 : mediaSource.DefaultAudioStreamIndex;

							let subtitleTrackIndexToSetOnPlaying = -1;
							for (let i = 0, length = mediaSource.MediaStreams.length; i < length; i++) {
								const track = mediaSource.MediaStreams[i];

								if (track.Type === 'Subtitle') {
									if (track.DeliveryMethod === 'External') {
										track.DeliveryUrl = getTextTrackUrl(track, item, mediaSource);
									}

									if (track.Index === mediaSource.DefaultSubtitleStreamIndex &&
										(track.DeliveryMethod === 'Embed' ||
											track.DeliveryMethod === 'External' ||
											track.DeliveryMethod === 'Hls' ||
											track.DeliveryMethod === 'VideoSideData')) {
										subtitleTrackIndexToSetOnPlaying = track.Index;
									}
								}
							}

							const isTranscoding = options.playMethod === 'Transcode';
							
							const postObject = {
								path: val,
								isLocal: mediaSource.IsLocal,
								itemId: item.Id,
								itemJson: JSON.stringify(item),
								mediaSourceJson: JSON.stringify(mediaSource),
								isTranscoding: isTranscoding,
								startPosMs: startPosMs,
								videoStreamIndex: videoStreamIndex,
								audioStreamIndex: audioStreamIndex,
								subtitleStreamIndex: subtitleTrackIndexToSetOnPlaying,
								posterUrl: posterUrl
							};

							EmbyPlayer.playVideo(this, postObject);

							onAfterSendPlayCommand(val, startPosMs);
						}
					} catch (err) {
						console.error('Encountered an error playing video: ' + err);
						reject(err);
					}
				});
			};

			function onAfterSendPlayCommand(src, startPositionMs) {
				const state = playerState;

				currentAspectRatio = 'auto';

				state.currentSrc = src;
				state.duration = null;
				state.paused = false;
				state.muted = false;
				state.volume = 100;
				state.cacheStart = null;
				state.cacheEnd = null;
				state.seekableRangeStart = null;
				state.seekableRangeEnd = null;
				state.started = null;
				state.subDelay = 0;
				state.playbackRate = 1;
				state.pipEnabled = false;

				state.currentTime = startPositionMs;
			}

			self.getSeekableRanges = () => {

				var state = playerState;
				if (state) {

					if (!state.seekableRangeStart || !state.seekableRangeEnd) {
						return [];
					}
	
					var rangeStart = state.seekableRangeStart;
					var rangeEnd = state.seekableRangeEnd;
	
					return [{
						start: (rangeStart * 10000),
						end: (rangeEnd * 10000)
					}];
				}
	
				return [];
			};

			self.getBufferedRanges = () => {
				const state = playerState;
				if (state) {
					let offset = 0;
					//var currentPlayOptions = instance._currentPlayOptions;
					//if (currentPlayOptions) {
					//    offset = currentPlayOptions.transcodingOffsetTicks;
					//}

					const cacheStart = state.cacheStart;
					const cacheEnd = state.cacheEnd;

					return [{
						start: ((cacheStart || 0) * 10000) + offset,
						end: ((cacheEnd || 0) * 10000) + offset
					}];
				}

				return [];
			};

			self.currentSrc = () => {
				if (playerState) {
					return playerState.currentSrc;
				}
			};

			self.paused = () => {
				if (playerState) {
					return playerState.paused;
				}

				return false;
			};

			self.seekable = () => true;

			function onPlayerDestroy() {
				brightnessValue = 100;
				playerState = {};
				currentPlayReject = null;
				currentPlayResolve = null;
			}

			self.destroy = () => {
				EmbyPlayer.destroy();
				onPlayerDestroy();
			};

			self.onEvent = name => {
				if (name === 'file-loaded') {
					playerState.started = true;

					const resolve = currentPlayResolve;
					playerState.currentTime = playerState.currentTime || 0;

					if (resolve) {
						currentPlayResolve = null;
						currentPlayReject = null;
						resolve();
					}
				} else if (name === 'end-file') {
					onEnded();
				} else if (name === 'ended') {
					onEnded();
				} else if (name === 'error') {
					onError();
				} else if (name === 'pip-started') {
					onPipModeChanged(true);
				} else if (name === 'pip-ended') {
					onPipModeChanged(false);
				}
			};

			self.onPropertyChange = (name, value) => {
				if (name === 'pause') {
					if (value === true) {
						playerState.paused = true;
						onPause();
					} else {
						playerState.paused = false;
						onUnpause();
					}
				} else if (name === 'time-pos') {
					playerState.currentTime = value;
					onTimeUpdate();
				} else if (name === 'duration') {
					playerState.duration = value;
				} else if (name === 'sub-delay') {
					playerState.subDelay = value;
				} else if (name === 'speed') {
					playerState.playbackRate = value;
					onRateChange();
				}
			};

			self.onCacheUpdate = (start, end) => {
				const state = playerState;
				state.cacheStart = start;
				state.cacheEnd = end;
			};

			self.onSeekableRangeUpdate = (start, end) => {
				const state = playerState;
				state.seekableRangeStart = start;
				state.seekableRangeEnd = end;
			};

			self.getSubtitleOffset = () => {
				if (playerState) {
					return playerState.subDelay;
				}
				return 0;
			};

			self.getPlaybackRate = () => {
				if (playerState) {
					return playerState.playbackRate;
				}
				return 1;
			};

			self.setPictureInPictureEnabled = (isEnabled) => {
				if (isEnabled) {
					sendMpvCommand('startPictureInPicture');
				} else {
					sendMpvCommand('stopPictureInPicture');
				}
			};

			self.isPictureInPictureEnabled = () => {
				return playerState.pipEnabled;
			};

			self.togglePictureInPicture = () => {
				return self.setPictureInPictureEnabled(!self.isPictureInPictureEnabled());
			};
		}

		setPlaybackRate(val) {
			sendMpvCommand('setPlaybackRate', val);
		}

		setSubtitleOffset(val) {
			sendMpvCommand('setSubtitleOffset', val);
		}

		incrementSubtitleOffset(val) {
			sendMpvCommand('incrementSubtitleOffset', val);
		}
	}

	return MpvVideoPlayer;
});
