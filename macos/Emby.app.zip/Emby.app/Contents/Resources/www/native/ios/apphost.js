define(['events', 'browser', './mediaprofilebuilder'], function (events, browser, mediaProfileBuilder) {
    'use strict';

    // ipad, iphone, ipod, mac
    var deviceType = window.applePlatform;

    console.log = function () { };
    window.addEventListener('error', function (evt) {

        let msg = "error";
        if (evt) {
            if (evt.message) { // Chrome sometimes provides this
                msg = evt.message + " at linenumber: " + evt.lineno + " of file: " + evt.filename;
            } else {
                msg = evt.type + " from element: " + (evt.srcElement || evt.target);
            }
            if (evt.error) {
                msg += "\n" + JSON.stringify(evt.error);
            }
        }
        window.webkit.messageHandlers.errorHandler.postMessage({ error: msg });
        //window.AppHost.alertTextWithOptions(msg);
    });

    window.addEventListener("unhandledrejection", function (evt) {

        let msg = "Unhandled Promise Rejection";
        if (evt) {
            msg += " (from element: " + (evt.srcElement || evt.target) + ", reason: " + evt.reason + ")";
        }
        window.webkit.messageHandlers.errorHandler.postMessage({ error: msg });
        //window.AppHost.alertTextWithOptions(msg);
    });

    function getSyncProfile(item) {

        return mediaProfileBuilder.buildProfile({
        });
    }

    function sharePolyfill(data) {
        return new Promise(function (resolve, reject) {
            if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.share) {
                window.webkit.messageHandlers.share.postMessage({
                    'message': data.text,
                    'subject': data.title,
                    'files': data.imageUrl,
                    'url': data.url
                });
                resolve();
            } else {
                reject(Error('Error sending share message to native app'));
            }
        });
    }

    function vibratePolyfill(data) {
        // For now, vibrate polyfil only accepts single argument duration in ms.
        if (!data || data.length) {
            return false;
        }
        if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.vibrate) {
            window.webkit.messageHandlers.vibrate.postMessage({
                'durationMs': data,
            });
            return true;
        } else {
            return false;
        }
    }

    function syncNow() {
        require(['localsync'], function (localSync) {
            localSync.sync();
        });
    }

    let deviceId;
    let deviceName;
    let appName;
    let appVersion;
    let fcmToken;

    let supportedFeatures = function () {

        let features = {};

        features.sync = true;
        features.cameraupload = true;

        features.sharing = true;
        features.exit = true;
        features.exitmenu = true;

        features.htmlaudioautoplay = true;
        features.htmlvideoautoplay = true;
        features.externallinks = true;

        features.multiserver = true;

        features.physicalvolumecontrol = true;
        features.nativevolumeosd = true;
        features.themesongvolume = true;

        features.remotecontrol = true;
        features.targetblank = true;

        features.subtitleappearancesettings = true;

        features.displaylanguage = true;
        features.youtube = true;
        features.youtube_embedded = true;

        features.chromecast = true;

        features.connectsignup = true;
        features.restrictedplugins = true;
        features.displaymode = true;
        features.serversetup = true;

        features.subtitlepositionbottom = true;
        features.forcetranscodingforformats = true;

        // not possible with the native player
        //features.subtitlepositiontop = true;

        return features;
    }();

    let appHost = {
        getWindowState: function () {
            return document.windowState || 'Normal';
        },
        setWindowState: function (state) {
            throw new Error('setWindowState is not supported and should not be called');
        },
        exit: function () {

            if (navigator.app && navigator.app.exitApp) {
                navigator.app.exitApp();
            } else {
                window.close();
            }
        },
        supports: function (command) {
            return supportedFeatures[command];
        },

        moreIcon: 'dots-horiz',
        getSyncProfile: getSyncProfile,

        init: function () {

            return getDeviceId().then(function (resolvedDeviceId) {

                deviceId = resolvedDeviceId;
                return getDeviceFcmToken().then(function (resolvedFcmToken) {

                    fcmToken = resolvedFcmToken;
                    return getDeviceName().then(function (resolvedDeviceName) {

                        // Remove special characters
                        deviceName = resolvedDeviceName || getDefaultDeviceName();
                        return getAppVersion().then(function (resolvedAppVersion) {

                            appVersion = resolvedAppVersion;
                            return getAppName().then(function (resolvedAppName) {

                                appName = resolvedAppName || getDefaultAppName();
                            });
                        });
                    });
                });

            });
        },

        deviceName: function () {
            return deviceName;
        },

        deviceId: function () {
            return deviceId;
        },

        appName: function () {
            return appName;
        },

        appVersion: function () {
            return appVersion;
        },

        getPushTokenInfo: function () {

            let info = {};

            if (fcmToken) {
                info.PushToken = fcmToken;
                info.PushTokenType = "firebase";
            }

            return info;
        },

        setTheme: function (themeSettings) {

            let metaThemeColor = document.querySelector("meta[name=theme-color]");
            if (metaThemeColor) {
                metaThemeColor.setAttribute("content", themeSettings.themeColor);
            }

            let isLightStatusBar = (themeSettings.themeColor || '').toLowerCase() === '#ffffff';

            window.webkit.messageHandlers.setStatusBarColor.postMessage({
                color: themeSettings.themeColor,
                isLightStatusBar: isLightStatusBar
            });
        },

        setUserScalable: function (scalable) {

            if (browser.tv) {
                return;
            }

            let att = scalable ?
                'viewport-fit=cover, width=device-width, initial-scale=1, minimum-scale=1, user-scalable=yes' :
                'viewport-fit=cover, width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no';

            document.querySelector('meta[name=viewport]').setAttribute('content', att);
        },

        deviceIconUrl: function () {

            if (deviceType === 'ipod' || deviceType === 'iphone') {
                return 'https://github.com/MediaBrowser/Emby.Resources/raw/master/images/devices/iphone.png';
            }

            if (deviceType === 'ipad' || deviceType === 'mac') {
                return 'https://github.com/MediaBrowser/Emby.Resources/raw/master/images/devices/ipad.png';
            }

            return 'https://github.com/MediaBrowser/Emby.Resources/raw/master/images/devices/ios.png';
        }
    };

    if (!navigator.share) {
        navigator.share = sharePolyfill;
    }

    if (!navigator.vibrate) {
        navigator.vibrate = vibratePolyfill;
    }

    if (!navigator.clipboard) {
        navigator.clipboard = {};
    }

    navigator.clipboard.writeText = function (text) {

        try {
            window.webkit.messageHandlers.copyToClipboard.postMessage({ text: text });
        }
        catch (err) {
            return Promise.reject(err);
        }
        return Promise.resolve();
    };

    let lastSyncTime = 0;
    function syncIfNeeded() {

        if (!appHost.supports('sync')) {
            return;
        }

        let now = new Date().getTime();
        if ((now - lastSyncTime) > 900000) {

            lastSyncTime = now;
            setTimeout(syncNow, 10000);
        }
    }

    function getAppVersion() {
        return new Promise(function (resolve, reject) {
            appHost.init.resolveAppVersion = resolve;
            try {
                window.webkit.messageHandlers.deviceInfo.postMessage({ command: 'getAppVersion' });
            }
            catch (err) {
                reject(err);
            }
        });
    }

    function getDeviceId() {

        return new Promise(function (resolve, reject) {
            appHost.init.resolveDeviceId = resolve;
            try {
                window.webkit.messageHandlers.deviceInfo.postMessage({ command: 'getDeviceId' });
            }
            catch (err) {
                reject(err);
            }
        });
    }

    function getDefaultDeviceName() {

        // browser.osx = ipados
        if (deviceType === 'ipad') {
            return 'iPad';
        }
        if (deviceType === 'iphone') {
            return 'iPhone';
        }
        if (deviceType === 'ipod') {
            return 'iPod';
        }
        if (deviceType === 'mac') {
            return 'Mac';
        }

        return 'iOS Device';
    }

    function getDeviceName() {

        return new Promise(function (resolve, reject) {
            appHost.init.resolveDeviceName = resolve;
            try {
                window.webkit.messageHandlers.deviceInfo.postMessage({ command: 'getDeviceName' });
            }
            catch (err) {
                resolve(getDefaultDeviceName());
            }
        });
    }

    function getAppName() {

        return new Promise(function (resolve, reject) {
            appHost.init.resolveAppName = resolve;
            try {
                window.webkit.messageHandlers.deviceInfo.postMessage({ command: 'getAppName' });
            }
            catch (err) {
                resolve(getDefaultAppName());
            }
        });
    }

    function getDefaultAppName() {
        return deviceType === 'mac' ? 'Emby for macOS' : 'Emby for iOS';
    }

    function getDeviceFcmToken() {

        return new Promise(function (resolve, reject) {
            appHost.resolveFcmToken = resolve;
            try {
                window.webkit.messageHandlers.deviceInfo.postMessage({ command: 'getFcmToken' });
            }
            catch (err) {
                reject(err);
            }
        });
    }

    function onAppResume() {
        console.log('triggering app resume event');
        events.trigger(appHost, 'resume');
        syncIfNeeded();
    }
    
    function onAppPause() {
        console.log('triggering app pause event');
        events.trigger(appHost, 'pause');
    }

    appHost.onNativeEvent = function (name) {

        // name = ios event name

        switch (name) {
            case 'resume':
                onAppResume();
                break;
            case 'pause':
                onAppPause();
                break;
            case 'closing':
                // this isn't used and instead AppCloseHandler.onAppClose is called. See mediasession.js
                break;
            default:
                break;
        }
    };

    appHost.setSystemUIHidden = function (hidden) {
        window.webkit.messageHandlers.setStatusBarHidden.postMessage({ 'hidden': hidden });
    };

    window.AppHost = appHost;

    if (!screen.orientation) {
        screen.orientation = {};
    }

    screen.orientation.onchange = function (event) {
        console.log('Orientation Changed');
    };

    if (deviceType === 'ipad' || deviceType === 'mac') {
        screen.orientation.lock = null;
    } else {
        screen.orientation.lock = function (mode) {
            
            window.webkit.messageHandlers.lockOrientation.postMessage({ orientation: mode });
            
            return Promise.resolve();
        };
    }

    screen.orientation.unlock = function () {
        window.webkit.messageHandlers.unlockOrientation.postMessage({});
    };

    if (!navigator.connection) {
        navigator.connection = {};
    }

    if (!navigator.connection.addEventListener) {
        navigator.connection.addEventListener = function (eventName, fn) {
            events.on(navigator.connection, eventName, fn);
        };
    }

    appHost.onNetworkChanged = function () {
        events.trigger(navigator.connection, 'change');
    };

    appHost.onPushTokenChanged = function (token) {

        fcmToken = token;

        require(['connectionManager'], function (connectionManager) {

            let server = connectionManager.getLastUsedServer();
            if (!server) {
                return;
            }

            let apiClient = connectionManager.getApiClient(server.Id);
            if (!apiClient || !apiClient.accessToken()) {
                return;
            }

            connectionManager.reportCapabilities(apiClient);

        });
    };

    document.addEventListener('viewshow', function viewDidLoad() {
        document.removeEventListener('viewshow', viewDidLoad);
        window.webkit.messageHandlers.appHostLoaded.postMessage({});
    });

    appHost.alertTextWithOptions = function (options) {
        require(['alert'], function (alert) {
            alert(options);
        });
    };

    return appHost;
});
