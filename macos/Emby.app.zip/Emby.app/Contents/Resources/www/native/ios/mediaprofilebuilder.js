/* jshint module: true */

import appSettings from './../../modules/common/appsettings.js';

function buildProfile() {
    let profile = {};

    // Only setting MaxStaticBitrate for older servers
    profile.MaxStreamingBitrate = profile.MaxStaticBitrate = 200000000;
    profile.MusicStreamingTranscodingBitrate = 192000;
    profile.MaxStaticMusicBitrate = appSettings.maxStaticMusicBitrate();

    profile.DirectPlayProfiles = [];

    // leave container null for all
    let videoDirectPlayProfile = {
        Type: 'Video'
    };

    // leave container null for all
    if (
        !(
            typeof window !== 'undefined' &&
            window.applePlatform === 'maccatalyst' &&
            window.buildScheme === 'direct-download'
        )
    ) {
        videoDirectPlayProfile.AudioCodec = '-truehd,ac4';
    }

    profile.DirectPlayProfiles.push(videoDirectPlayProfile);

    // leave container null for all
    profile.DirectPlayProfiles.push({
        Type: 'Audio'
    });

    profile.TranscodingProfiles = [];

    profile.TranscodingProfiles.push({
        Container: 'ts',
        Type: 'Video',
        AudioCodec: 'ac3,mp3,aac',
        VideoCodec: 'h264,hevc,mpeg2video',
        Context: 'Streaming',
        Protocol: 'hls',
        MaxAudioChannels: '6',
        MinSegments: '1',
        BreakOnNonKeyFrames: true,
        SegmentLength: '3'
    });

    profile.TranscodingProfiles.push({
        Container: 'ts',
        Type: 'Audio',
        AudioCodec: 'aac',
        Context: 'Streaming',
        Protocol: 'hls',
        MinSegments: '1',
        SegmentLength: '3',
        BreakOnNonKeyFrames: true
    });

    profile.TranscodingProfiles.push({
        Container: 'mp3',
        Type: 'Audio',
        AudioCodec: 'mp3',
        Context: 'Streaming',
        Protocol: 'http'
    });

    profile.TranscodingProfiles.push({
        Container: 'mkv',
        Type: 'Video',
        AudioCodec: 'aac,mp3,ac3',
        VideoCodec: 'h264',
        Context: 'Static',
        MaxAudioChannels: '2'
    });

    profile.TranscodingProfiles.push({
        Container: 'mp3',
        Type: 'Audio',
        AudioCodec: 'mp3',
        Context: 'Static',
        Protocol: 'http',
        MaxAudioChannels: '2'
    });

    profile.ContainerProfiles = [];

    profile.CodecProfiles = [];

    profile.CodecProfiles.push({
        Type: 'Video',
        Codec: 'hevc',
        Conditions: [
            {
                Condition: 'EqualsAny',
                Property: 'VideoProfile',
                Value: 'Main|Main 10'
            }
        ]
    });

    // Subtitle profiles
    // External vtt or burn in
    profile.SubtitleProfiles = [];
    profile.SubtitleProfiles.push({
        Format: 'srt',
        Method: 'External'
    });
    profile.SubtitleProfiles.push({
        Format: 'ssa',
        Method: 'External'
    });
    profile.SubtitleProfiles.push({
        Format: 'ass',
        Method: 'External'
    });
    profile.SubtitleProfiles.push({
        Format: 'vtt',
        Method: 'External'
    });
    profile.SubtitleProfiles.push({
        Format: 'srt',
        Method: 'Embed'
    });
    profile.SubtitleProfiles.push({
        Format: 'subrip',
        Method: 'Embed'
    });
    profile.SubtitleProfiles.push({
        Format: 'ass',
        Method: 'Embed'
    });
    profile.SubtitleProfiles.push({
        Format: 'ssa',
        Method: 'Embed'
    });
    profile.SubtitleProfiles.push({
        Format: 'dvb_teletext',
        Method: 'Embed'
    });
    profile.SubtitleProfiles.push({
        Format: 'dvb_subtitle',
        Method: 'Embed'
    });
    profile.SubtitleProfiles.push({
        Format: 'dvbsub',
        Method: 'Embed'
    });
    profile.SubtitleProfiles.push({
        Format: 'pgs',
        Method: 'Embed'
    });
    profile.SubtitleProfiles.push({
        Format: 'pgssub',
        Method: 'Embed'
    });
    profile.SubtitleProfiles.push({
        Format: 'dvdsub',
        Method: 'Embed'
    });
    profile.SubtitleProfiles.push({
        Format: 'vtt',
        Method: 'Embed'
    });
    profile.SubtitleProfiles.push({
        Format: 'sub',
        Method: 'Embed'
    });
    profile.SubtitleProfiles.push({
        Format: 'idx',
        Method: 'Embed'
    });
    profile.SubtitleProfiles.push({
        Format: 'smi',
        Method: 'Embed'
    });
    profile.SubtitleProfiles.push({
        Format: 'mov_text',
        Method: 'Embed'
    });

    profile.ResponseProfiles = [];

    return Promise.resolve(profile);
}

export default {
    buildProfile: buildProfile
};
