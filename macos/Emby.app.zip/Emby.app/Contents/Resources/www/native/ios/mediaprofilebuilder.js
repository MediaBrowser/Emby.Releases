define(['appSettings'], function (appSettings) {

    'use strict';

    function filterContainersOrCodec(stringValue, forceTranscodingForFormats) {
        return stringValue.split(',').filter(function (v) {

            return !forceTranscodingForFormats.includes(v);

        }).join(',') || null;
    }

    function buildProfile() {
        let profile = {};

        // Only setting MaxStaticBitrate for older servers
        profile.MaxStreamingBitrate = profile.MaxStaticBitrate = 200000000;
        profile.MusicStreamingTranscodingBitrate = 192000;
        profile.MaxStaticMusicBitrate = appSettings.maxStaticMusicBitrate();

        profile.DirectPlayProfiles = [];

        let videoDirectPlayProfile = {
            Type: 'Video'
        };

        let preferredVideoPlayer = appSettings.preferredVideoPlayer();

        let forceTranscodingForContainers = appSettings.forceTranscodingForContainers();
        let forceTranscodingForVideoCodecs = appSettings.forceTranscodingForVideoCodecs();

        if (preferredVideoPlayer === 'native') {
            videoDirectPlayProfile.VideoCodec = filterContainersOrCodec('h264,hevc', forceTranscodingForVideoCodecs);
            videoDirectPlayProfile.AudioCodec = 'eac3,ac3,aac,mp3';
            videoDirectPlayProfile.Container = filterContainersOrCodec('mp4,m4v', forceTranscodingForContainers);
        } else {

            if (forceTranscodingForContainers.length) {
                videoDirectPlayProfile.Container = '-' + forceTranscodingForContainers.join(',');
            }
            if (forceTranscodingForVideoCodecs.length) {
                videoDirectPlayProfile.VideoCodec = '-' + forceTranscodingForVideoCodecs.join(',');
            }

            // leave container null for all
            if (
                !(
                    typeof window !== 'undefined' &&
                    window.applePlatform === 'maccatalyst' &&
                    window.buildScheme === 'direct-download'
                )
            ) {
                videoDirectPlayProfile.AudioCodec = '-truehd,ac4';
            }
        }

        profile.DirectPlayProfiles.push(videoDirectPlayProfile);

        // leave container null for all
        profile.DirectPlayProfiles.push({
            Type: 'Audio'
        });

        profile.TranscodingProfiles = [];

        let videoHlsTranscodingProfile = {
            Container: 'ts',
            Type: 'Video',
            AudioCodec: 'ac3,eac3,mp3,aac',
            Context: 'Streaming',
            Protocol: 'hls',
            MaxAudioChannels: '6',
            MinSegments: '1',
            BreakOnNonKeyFrames: true,
            SegmentLength: '3',
            fillEmptySubtitleSegments: true
        };

        if (preferredVideoPlayer === 'native') {
            videoHlsTranscodingProfile.VideoCodec = 'h264';
        } else {
            videoHlsTranscodingProfile.VideoCodec = 'h264,hevc,mpeg2video';
        }

        if (preferredVideoPlayer === 'mpv') {
            videoHlsTranscodingProfile.AudioCodec += ',flac';
        }

        videoHlsTranscodingProfile.ManifestSubtitles = 'vtt';

        profile.TranscodingProfiles.push(videoHlsTranscodingProfile);

        profile.TranscodingProfiles.push({
            Container: 'ts',
            Type: 'Audio',
            AudioCodec: 'aac',
            Context: 'Streaming',
            Protocol: 'hls',
            MinSegments: '1',
            SegmentLength: '3',
            BreakOnNonKeyFrames: true
        });

        profile.TranscodingProfiles.push({
            Container: 'mp3',
            Type: 'Audio',
            AudioCodec: 'mp3',
            Context: 'Streaming',
            Protocol: 'http'
        });

        profile.TranscodingProfiles.push({
            Container: 'mkv',
            Type: 'Video',
            AudioCodec: 'aac,mp3,ac3',
            VideoCodec: 'h264',
            Context: 'Static',
            MaxAudioChannels: '2'
        });

        profile.TranscodingProfiles.push({
            Container: 'mp3',
            Type: 'Audio',
            AudioCodec: 'mp3',
            Context: 'Static',
            Protocol: 'http',
            MaxAudioChannels: '2'
        });

        profile.ContainerProfiles = [];

        profile.CodecProfiles = [];

        // TODO: Need universal iOS/Apple TV detection for this
        let maxVideoWidth = 3840;

        if (preferredVideoPlayer === 'native') {
            profile.CodecProfiles.push({
                Type: 'VideoAudio',
                Conditions: [
                    {
                        Condition: 'NotEquals',
                        Property: 'AudioProfile',
                        Value: 'HE-AAC',
                        IsRequired: true
                    },
                    {
                        Condition: 'Equals',
                        Property: 'IsSecondaryAudio',
                        Value: 'false',
                        IsRequired: false
                    },
                    {
                        Condition: 'LessThanEqual',
                        Property: 'AudioChannels',
                        Value: '2',
                        IsRequired: true
                    }
                ],
                Codec: 'aac'
            });

            profile.CodecProfiles.push({
                Type: 'VideoAudio',
                Conditions: [
                    {
                        Condition: 'Equals',
                        Property: 'IsSecondaryAudio',
                        Value: 'false',
                        IsRequired: false
                    }
                ]
            });

            profile.CodecProfiles.push({
                Type: 'Video',
                Conditions: [
                    {
                        Condition: 'EqualsAny',
                        Property: 'VideoProfile',
                        Value: 'high|main|baseline|constrained baseline',
                        IsRequired: true
                    },
                    {
                        Condition: 'NotEquals',
                        Property: 'IsInterlaced',
                        Value: 'true',
                        IsRequired: false
                    },
                    {
                        Condition: 'LessThanEqual',
                        Property: 'VideoLevel',
                        Value: '42',
                        IsRequired: true
                    },
                    {
                        Condition: 'LessThanEqual',
                        Property: 'Width',
                        Value: maxVideoWidth,
                        IsRequired: true
                    }
                ],
                Codec: 'h264'
            });

            profile.CodecProfiles.push({
                Type: 'Video',
                Conditions: [
                    {
                        Condition: 'EqualsAny',
                        Property: 'VideoProfile',
                        Value: 'main|main 10',
                        IsRequired: true
                    },
                    {
                        Condition: 'Equals',
                        Property: 'VideoCodecTag',
                        Value: 'hvc1',
                        IsRequired: true
                    },
                    {
                        Condition: 'LessThanEqual',
                        Property: 'Width',
                        Value: maxVideoWidth,
                        IsRequired: true
                    }
                ],
                Codec: 'hevc'
            });

            profile.CodecProfiles.push({
                Type: 'Video',
                Conditions: [
                    {
                        Condition: 'NotEquals',
                        Property: 'IsAnamorphic',
                        Value: 'true',
                        IsRequired: false
                    },
                    {
                        Condition: 'LessThanEqual',
                        Property: 'Width',
                        Value: maxVideoWidth,
                        IsRequired: true
                    }
                ],
                Codec: 'vpx'
            });
        } else {
            profile.CodecProfiles.push({
                Type: 'Video',
                Codec: 'hevc',
                Conditions: [
                    {
                        Condition: 'EqualsAny',
                        Property: 'VideoProfile',
                        Value: 'Main|Main 10'
                    }
                ]
            });
        }

        // Subtitle profiles
        // External vtt or burn in
        profile.SubtitleProfiles = [];

        profile.SubtitleProfiles.push({
            Format: 'mov_text',
            Method: 'Embed'
        });
        profile.SubtitleProfiles.push({
            Format: 'vtt',
            Method: 'External'
        });
        profile.SubtitleProfiles.push({
            Format: 'vtt',
            Method: 'Hls'
        });

        if (preferredVideoPlayer !== 'native') {
            profile.SubtitleProfiles.push({
                Format: 'srt',
                Method: 'External'
            });
            profile.SubtitleProfiles.push({
                Format: 'ssa',
                Method: 'External'
            });
            profile.SubtitleProfiles.push({
                Format: 'ass',
                Method: 'External'
            });
            profile.SubtitleProfiles.push({
                Format: 'srt',
                Method: 'Embed'
            });
            profile.SubtitleProfiles.push({
                Format: 'subrip',
                Method: 'Embed'
            });
            profile.SubtitleProfiles.push({
                Format: 'ass',
                Method: 'Embed'
            });
            profile.SubtitleProfiles.push({
                Format: 'ssa',
                Method: 'Embed'
            });
            profile.SubtitleProfiles.push({
                Format: 'dvb_teletext',
                Method: 'Embed'
            });
            profile.SubtitleProfiles.push({
                Format: 'dvb_subtitle',
                Method: 'Embed'
            });
            profile.SubtitleProfiles.push({
                Format: 'dvbsub',
                Method: 'Embed'
            });
            profile.SubtitleProfiles.push({
                Format: 'pgs',
                Method: 'Embed'
            });
            profile.SubtitleProfiles.push({
                Format: 'pgssub',
                Method: 'Embed'
            });
            profile.SubtitleProfiles.push({
                Format: 'dvdsub',
                Method: 'Embed'
            });
            profile.SubtitleProfiles.push({
                Format: 'dvdsub',
                Method: 'External'
            });
            profile.SubtitleProfiles.push({
                Format: 'vtt',
                Method: 'Embed'
            });
            profile.SubtitleProfiles.push({
                Format: 'sub',
                Method: 'Embed'
            });
            profile.SubtitleProfiles.push({
                Format: 'idx',
                Method: 'Embed'
            });
            profile.SubtitleProfiles.push({
                Format: 'smi',
                Method: 'Embed'
            });
            profile.SubtitleProfiles.push({
                Format: 'eia_608',
                Method: 'VideoSideData'
            });
            profile.SubtitleProfiles.push({
                Format: 'eia_708',
                Method: 'VideoSideData'
            });
        }

        profile.ResponseProfiles = [];

        return Promise.resolve(profile);
    }

    return {
        buildProfile: buildProfile
    };
});
