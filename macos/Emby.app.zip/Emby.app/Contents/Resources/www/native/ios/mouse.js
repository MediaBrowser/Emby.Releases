define(['events', 'mouseManager'], function (events, mouseManager) {

    'use strict';

    events.on(mouseManager, 'mouseidlestart', function() {
        window.webkit.messageHandlers.setMouseHidden.postMessage({
            hidden: true
        });
    });

    events.on(mouseManager, 'mouseidlestop', function() {
        window.webkit.messageHandlers.setMouseHidden.postMessage({
            hidden: false
        });
    });
});